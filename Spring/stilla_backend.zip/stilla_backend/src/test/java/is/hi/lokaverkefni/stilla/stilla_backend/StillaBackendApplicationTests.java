package is.hi.lokaverkefni.stilla.stilla_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StillaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
